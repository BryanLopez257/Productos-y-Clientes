<%@page import="com.google.gson.*"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head><title>Pedidos del Cliente</title></head>
    <body>
        <h1>Pedidos de Cédula: <%= request.getAttribute("cedulaActual") %></h1>

        <h3>Realizar Nuevo Pedido</h3>
        <form action="SvPedidos" method="POST">
            <input type="hidden" name="cedula" value="<%= request.getAttribute("cedulaActual") %>">

            <label>Seleccione un Producto:</label>
            <select name="producto" required>
                <option value="">-- Seleccione un producto --</option>
                <% 
                    // 1. Asegúrate de que el nombre coincida con el setAttribute del Servlet
                    com.google.gson.JsonArray listaProds = (com.google.gson.JsonArray) request.getAttribute("productosDisponibles");
        
                    if(listaProds != null && listaProds.size() > 0) {
                        for(int i = 0; i < listaProds.size(); i++) { 
                            com.google.gson.JsonObject pr = listaProds.get(i).getAsJsonObject(); 
                %>
                <option value="<%= pr.get("NOMBRE_PRODUCTO").getAsString() %>">
                    <%= pr.get("NOMBRE_PRODUCTO").getAsString() %>
                </option>
                <% 
                        } 
                    } else {
                %>
                <option value="">No se cargaron productos de la API</option>
                <% } %>
            </select>

            <button type="submit">Confirmar Pedido</button>
        </form>
        <table border="1">
            <tr><th>ID Pedido</th><th>Producto</th><th>Fecha</th></tr>
                    <% JsonArray pedidos = (JsonArray) request.getAttribute("pedidos");
                       if(pedidos != null) {
                           for(JsonElement e : pedidos) { JsonObject p = e.getAsJsonObject(); %>
            <tr>
                <td><%= p.get("ID_PEDIDO").getAsString() %></td>
                <td><%= p.get("NOMBRE_PRODUCTO").getAsString() %></td>
                <td><%= p.get("FECHA_PEDIDO").getAsString() %></td>
            </tr>
            <% } } %>
        </table>
        <br><a href="SvClientes">Volver a Clientes</a>
    </body>
</html>