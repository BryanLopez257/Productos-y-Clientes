<%@page import="com.google.gson.*"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head><title>Lista de Clientes</title></head>
<body>
    <h1>Clientes Registrados</h1>
    <form action="SvClientes" method="GET">
        <input type="text" name="cedula" placeholder="Buscar por Cédula">
        <button type="submit">Buscar</button>
    </form>
    <table border="1">
        <tr><th>Cédula</th><th>Nombre</th><th>Apellido</th><th>Acciones</th></tr>
        <% JsonArray lista = (JsonArray) request.getAttribute("clientes");
           if(lista != null) {
               for(JsonElement e : lista) { JsonObject c = e.getAsJsonObject(); %>
               <tr>
                   <td><%= c.get("CEDULA_CLIENTE").getAsString() %></td>
                   <td><%= c.get("NOMBRE_CLIENTE").getAsString() %></td>
                   <td><%= c.get("APELLIDO_CLIENTE").getAsString() %></td>
                   <td><a href="SvPedidos?cedula=<%= c.get("CEDULA_CLIENTE").getAsString() %>">Ver Pedidos</a></td>
               </tr>
        <% } } %>
    </table>
</body>
</html>