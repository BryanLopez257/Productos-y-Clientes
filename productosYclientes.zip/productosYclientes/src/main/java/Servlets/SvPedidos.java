/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Servlets;

import Controller.ConsumirApiPHP;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 *
 * @author bl250
 */
@WebServlet(name = "SvPedidos", urlPatterns = {"/SvPedidos"})
public class SvPedidos extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String cedula = request.getParameter("cedula");
        if (cedula != null) {
            // Carga pedidos del cliente
            request.setAttribute("pedidos", ConsumirApiPHP.getPedidosPorCliente(cedula));
            // Carga productos disponibles para el formulario
            // Asegúrate de que diga esto exactamente:
            request.setAttribute("productosDisponibles", ConsumirApiPHP.getProductosExistentes());
            request.setAttribute("cedulaActual", cedula);
        }
        request.getRequestDispatcher("/pedidos.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String cedula = request.getParameter("cedula");
        String producto = request.getParameter("producto");
        ConsumirApiPHP.insertarPedido(cedula, producto);
        response.sendRedirect("SvPedidos?cedula=" + cedula);
    }

}
