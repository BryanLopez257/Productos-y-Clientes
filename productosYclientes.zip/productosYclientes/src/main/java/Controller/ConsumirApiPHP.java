package Controller;

import com.google.gson.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;

public class ConsumirApiPHP {

    private static final String URL_CLIENTES = "http://localhost/Apis/ApiClientes.php";
    private static final String URL_PEDIDOS = "http://localhost/Apis/ApiPedidos.php";
    private static final String URL_PRODUCTOS_LISTA = "http://localhost/Apis/ApiProductos.php";
    private static final HttpClient cliente = HttpClient.newHttpClient();

    private static JsonArray fetch(String urlApi) {
        try {
            URL url = new URL(urlApi);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            if (conn.getResponseCode() == 200) {
                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
                return JsonParser.parseReader(br).getAsJsonArray();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new JsonArray();
    }

    // Listar Clientes
    public static JsonArray getClientes() {
        return fetch(URL_CLIENTES);
    }

    // Buscar Cliente por Cédula
    public static JsonArray getClientePorCedula(String cedula) {
        return fetch(URL_CLIENTES + "?cedula=" + URLEncoder.encode(cedula, StandardCharsets.UTF_8));
    }

    // Listar Pedidos de un Cliente
    public static JsonArray getPedidosPorCliente(String cedula) {
        return fetch(URL_PEDIDOS + "?cedula=" + URLEncoder.encode(cedula, StandardCharsets.UTF_8));
    }

    // Insertar Pedido (POST)
    public static boolean insertarPedido(String cedula, String producto) {
        try {
            String params = "cedula=" + URLEncoder.encode(cedula, StandardCharsets.UTF_8)
                    + "&producto=" + URLEncoder.encode(producto, StandardCharsets.UTF_8);

            HttpRequest req = HttpRequest.newBuilder()
                    .uri(new URI(URL_PEDIDOS))
                    .header("Content-Type", "application/x-www-form-urlencoded")
                    .POST(HttpRequest.BodyPublishers.ofString(params))
                    .build();

            return cliente.send(req, HttpResponse.BodyHandlers.ofString()).statusCode() == 200;
        } catch (Exception e) {
            return false;
        }
    }

    

    public static JsonArray getProductosExistentes() {
        return fetch(URL_PRODUCTOS_LISTA);
    }
}
