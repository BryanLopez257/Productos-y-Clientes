<?php
include_once "CrudPedidos.php";
include_once "CrudClientes.php"; // Debes crear uno similar para listar clientes
header("Content-Type: application/json");

$metodo = $_SERVER['REQUEST_METHOD'];

switch($metodo) {
    case 'GET':
        if(isset($_GET['cedula'])) {
            CrudPedidos::getPedidosPorCliente($_GET['cedula']);
        } else {
            // Aquí llamarías a un método para listar todos los clientes si es necesario
        }
        break;
    case 'POST':
        // Java enviará los datos por POST (x-www-form-urlencoded o JSON)
        $cedula = $_POST['cedula'] ?? '';
        $producto = $_POST['producto'] ?? '';
        CrudPedidos::insertar($cedula, $producto);
        break;
}
?>