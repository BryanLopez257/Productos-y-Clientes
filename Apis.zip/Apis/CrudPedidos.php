<?php
include_once "Conexion.php";

class CrudPedidos
{
    public static function getPedidosPorCliente($cedula) {
    $con = (new Conexion())->conectar();
    // l.created_at lo enviamos como FECHA_PEDIDO para Java
    $sql = "SELECT p.id AS ID_PEDIDO, c.nombre AS NOMBRE_CLIENTE, pr.nombre AS NOMBRE_PRODUCTO, p.created_at AS FECHA_PEDIDO 
            FROM pedidos p
            JOIN clientes c ON p.cliente_id = c.id
            JOIN productos pr ON p.producto_id = pr.id
            WHERE c.cedula = :cedula";
    $stmt = $con->prepare($sql);
    $stmt->execute(['cedula' => $cedula]);
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
}

public static function insertar($cedula, $nombreProducto) {
    $con = (new Conexion())->conectar();
    
    // Buscar ID del cliente usando la columna 'cedula' de Laravel
    $stmtC = $con->prepare("SELECT id FROM clientes WHERE cedula = ?");
    $stmtC->execute([$cedula]);
    $cliente = $stmtC->fetch();

    // Buscar ID del producto usando la columna 'nombre' de Laravel
    $stmtP = $con->prepare("SELECT id FROM productos WHERE nombre = ?");
    $stmtP->execute([$nombreProducto]);
    $producto = $stmtP->fetch();

    if ($cliente && $producto) {
        $sql = "INSERT INTO pedidos (cliente_id, producto_id, created_at, updated_at) VALUES (?, ?, NOW(), NOW())";
        $con->prepare($sql)->execute([$cliente['id'], $producto['id']]);
        echo json_encode(["status" => "OK"]);
    } else {
        http_response_code(404);
        echo json_encode(["error" => "No encontrado"]);
    }
}

    public static function update()
    {
        $conexion = new Conexion();
        $conectar = $conexion->conectar();
        $id = $_GET['ID_AUTOR'];
        $nombre = $_GET['NOMBRE_AUTOR'];
        $correo = $_GET['CORREO_AUTOR'];
        $sqlUpdate = "UPDATE AUTORES SET NOMBRE_AUTOR='$nombre', CORREO_AUTOR='$correo' WHERE ID_AUTOR='$id'";
        $resultado = $conectar->prepare($sqlUpdate);
        $resultado->execute();
        $data = "Actualizado";
        echo json_encode($data);
    }

    public static function delete()
    {
        $conexion = new Conexion();
        $conectar = $conexion->conectar();
        if (isset($_GET['ID_AUTOR'])) {
            $id = $_GET['ID_AUTOR'];
        } else {
            http_response_code(400);
            echo json_encode(["error" => "Falta el parámetro 'ID_AUTOR'"]);
            return;
        }
        $sqlDelete = "DELETE FROM AUTORES WHERE ID_AUTOR='$id'";
        $resultado = $conectar->prepare($sqlDelete);
        $resultado->execute();
        $data = "Eliminado";
        echo json_encode($data);
    }

    public static function buscar()
    {
        $conexion = new Conexion();
        $conectar = $conexion->conectar();
        $id = $_GET['ID_AUTOR'];
        $sqlConsulta = "SELECT * FROM AUTORES WHERE ID_AUTOR='$id'";
        $resultado = $conectar->prepare($sqlConsulta);
        $resultado->execute();
        $data = $resultado->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($data);
    }
}
?>
