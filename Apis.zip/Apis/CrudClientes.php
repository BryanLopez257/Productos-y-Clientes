<?php
include_once "Conexion.php";

class CrudClientes {
    public static function listarTodos() {
    $conexion = new Conexion();
    $conectar = $conexion->conectar();
    // Convertimos los nombres de Laravel a los nombres que espera tu Java
    $sql = "SELECT id AS ID_CLIENTE, cedula AS CEDULA_CLIENTE, nombre AS NOMBRE_CLIENTE, apellido AS APELLIDO_CLIENTE FROM clientes";
    $resultado = $conectar->prepare($sql);
    $resultado->execute();
    echo json_encode($resultado->fetchAll(PDO::FETCH_ASSOC));
}

public static function buscarPorCedula($cedula) {
    $conexion = new Conexion();
    $conectar = $conexion->conectar();
    $sql = "SELECT id AS ID_CLIENTE, cedula AS CEDULA_CLIENTE, nombre AS NOMBRE_CLIENTE, apellido AS APELLIDO_CLIENTE FROM clientes WHERE cedula = ?";
    $resultado = $conectar->prepare($sql);
    $resultado->execute([$cedula]);
    echo json_encode($resultado->fetchAll(PDO::FETCH_ASSOC));
}
}
?>