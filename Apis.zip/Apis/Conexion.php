<?php
  class Conexion {
    public function conectar() {
      $servername = "localhost";
      $dsn = "mysql:host=$servername;dbname=productos";
      $username = "root";
      $password = "";

      try {
        $conn = new PDO($dsn, $username, $password);
      } catch(Exception $e) {
        die("Fallo: " . $e->getMessage());
      }
      return $conn;
    }
  }
?>