<?php
include_once "Conexion.php";
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$con = (new Conexion())->conectar();

// QUITAMOS 'stock' de la consulta porque no existe en la tabla
$sql = "SELECT id AS ID_PRODUCTO, nombre AS NOMBRE_PRODUCTO FROM productos";
$stmt = $con->prepare($sql);
$stmt->execute();

echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
?>