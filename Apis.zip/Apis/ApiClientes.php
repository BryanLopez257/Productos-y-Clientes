<?php

// Permitir acceso desde cualquier origen (CORS) - Útil para desarrollo
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

include_once "CrudClientes.php";

// Obtenemos el método de la petición (GET, POST, etc.)
$metodo = $_SERVER['REQUEST_METHOD'];

switch ($metodo) {
    case 'GET':
        // Si en la URL viene ?cedula=123... buscamos uno solo
        // ApiClientes.php
        if (isset($_GET['cedula']) && !empty($_GET['cedula'])) {
            // Si hay cédula en la URL, busca uno solo
            CrudClientes::buscarPorCedula($_GET['cedula']);
        } else {
            // Si NO hay cédula (como cuando presionas "Mostrar Clientes"), lista todos
            CrudClientes::listarTodos();
        }
        break;

    default:
        http_response_code(405);
        echo json_encode(["message" => "Método no permitido"]);
        break;
}
?>